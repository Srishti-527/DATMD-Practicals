﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";
    var rand, questions, answers, ques;
    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );
    
    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener('resume', onResume.bind(this), false);
        document.getElementById("sub").addEventListener('click', calc.bind(this), false);
        show();
        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };
})();
function show() {
    questions = ['2102', '4687', '9487'];
    answers = ['2210', '8764','9874'];
    rand = Math.floor(Math.round(Math.random() * (questions.length - 1)));
    ques = questions[rand];
    document.getElementById("ques").innerHTML = ques;
};
function calc() {
    if (document.getElementById("ans").value.toLowerCase() == answers[rand])
        document.getElementById("fd").innerHTML = "Your answer is correct.";
    else
        document.getElementById("fd").innerHTML = "Your answer is not correct. Please try again.";

};

