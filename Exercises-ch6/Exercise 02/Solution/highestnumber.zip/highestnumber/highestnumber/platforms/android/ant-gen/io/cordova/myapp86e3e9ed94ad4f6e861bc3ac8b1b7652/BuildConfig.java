/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp86e3e9ed94ad4f6e861bc3ac8b1b7652;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}