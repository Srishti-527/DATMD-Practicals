/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp7f66a076259449b2a41edabfda732ff3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}