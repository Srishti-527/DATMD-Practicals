/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myappbc21a6fbc3e64644b57aa0a6fe60d299;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}