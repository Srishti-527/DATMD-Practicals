/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp914fbdc5dd374742b58c503696948359;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}