/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp530d84a23b934d0c901378e15fc97e15;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}