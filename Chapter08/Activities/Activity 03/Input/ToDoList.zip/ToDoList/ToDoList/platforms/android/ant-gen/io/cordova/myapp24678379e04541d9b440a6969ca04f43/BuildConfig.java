/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp24678379e04541d9b440a6969ca04f43;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}