/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp8855a5512126418880acb40dde600aba;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}