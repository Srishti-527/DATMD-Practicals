﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";
    var taskInputModel = function () {
        var name = '';
        var phone = '';
        $.subscribe('desc-input-value', function (event, data) {
            name = data;
        });
        $.subscribe('desc-input-value1', function (event, data) {
            phone = data;
        });
        this.getPhone = function () {
            return phone;
        }
        this.getName = function () {
            return name;
        }
        this.setPhone = function (data) {
            phone = data;
            $.publish('desc-input-value1', data);
            $.publish('desc-stored-value1', data);
        }
        this.setName = function (data) {
            name = data;
            $.publish('desc-input-value', data);
            $.publish('desc-stored-value', data);
        }
    };
    var task = new taskInputModel();
    var tasks = [];

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener( 'resume', onResume.bind( this ), false );
        document.getElementById('addBtn').addEventListener('click', onAdd.bind(this), false);
        document.getElementById('saveBtn').addEventListener('click', onSave.bind(this), false);
        document.getElementById('main').addEventListener('')
        showTaskList();

        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };
    function onAdd() {
        $.UIGoToArticle("#addTask");
    };

    $("#contnum").on('input', function (e) {
        $.publish('desc-input-value', $(this).val());
    });
    $("#name1").on('input', function (e) {
        $.publish('desc-input-value1', $(this).val());
    });

    var updateStoredDesc = $.subscribe('desc-stored-value', function (event, data) {
        $('#contnum').val(data);
    });
    var updateStoredDesc1 = $.subscribe('desc-stored-value1', function (event, data) {
        $('#name1').val(data);
    });
    
    function onSave() {
        var t = { name: task.getName(), phone: task.getPhone() }
        
        tasks.push(t);
        task.setName("");
        task.setPhone("");
        showTaskList();
        $.UIGoBackToArticle("#main");
    };
    function showTaskList() {
        if (tasks.length == 0) {
            document.getElementById("headerMain").innerText = "No contacts added.";
        }
        else {
            $("#conList").empty();
            document.getElementById("headerMain").innerText = "My Contacts";
            var Temp = '<li><h4>[[= data.phone ]]</h4><h4>[[= data.name ]]</h4></li>';
            var myTmp = $.template(Temp);
            tasks.forEach(function (item) {
                $("#conList").append(myTmp(item));
            });
        }
    }

})();
