﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";
    var taskInputModel = function (){
        var name = '';
        var phone = '';
        $.subscribe('desc-input-value', function (event, data) {
            name = data;
        });
        $.subscribe('desc-input-value1', function (event, data) {
            phone = data;
        });
        this.getName = function () {
            return name;
        }
        this.getPhone = function () {
            return phone;
        }
        this.setName = function (data) {
            name = data;
            $.publish('desc-input-value', data);
            $.publish('desc-stored-value', data);
        }
        this.setPhone = function (data) {
            phone = data;
            $.publish('desc-input-value1', data);
            $.publish('desc-stored-value1', data);
        }
    };
    var task = new taskInputModel();
    var tasks = [];
    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );
    
    if ($.isWin) {
        document.getElementById('themeStylesheet').setAttribute('href', './css/chui-win-3.8.5.min.css');
        $('#mainNav').append('<div class="segmented horizontal align-flush"><button id="addBtn">Add Contact</button></div>');
        $('#addNav').append('<div class="segmented horizontal align-flush"><button id="saveBtn">Save Contact</button></div>');
    } else {
        document.getElementById('themeStylesheet').setAttribute('href', './css/chui-android-3.8.5.min.css');
        $('#mainNav').append('<button id="addBtn">Add Contact</button>');
        $('#addNav').append('<button id="saveBtn">Save Contact</button>');

    }


    function onDeviceReady() {

        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener('resume', onResume.bind(this), false);

        if (localStorage.toDoList) {

            tasks = JSON.parse(localStorage.toDoList);
        }
        showList();
        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };

    $('#addBtn').on('singletap', function () {
        $.UIGoToArticle("#addCont");
    });

    $("#name1").on('input', function (e) {
        $.publish('desc-input-value', $(this).val());
    });
    $("#num").on('input', function (e) {
        $.publish('desc-input-value1', $(this).val());
    });

    var updateStoredDesc = $.subscribe('desc-stored-value', function (event, data) {
        $('#name1').val (data);
    });
    var updateStoredDesc1 = $.subscribe('desc-stored-value1', function (event, data) {
        $('#num').val(data);
    });

     $('#saveBtn').on('singletap', function(){
        var t = { name: task.getName(), phone: task.getPhone() }
        tasks.push(t);
        localStorage.toDoList = JSON.stringify(tasks);
        task.setName("");
        task.setPhone("");
        showList();
        $.UIGoBackToArticle("#main");
    });

    function showList(){
        if (tasks.length == 0) {
            $("#contList").empty();
            document.getElementById("headerMain").innerText = "No contacts exist.";
        }
        else {
            $("#contList").empty();
            document.getElementById("headerMain").innerText = "My Contacts";

            var Temp = '<li><h4>[[= data.name ]]</h4><h4>[[= data.phone ]]</h4></li>';
             var myTmp = $.template(Temp);
             tasks.forEach(function (item) {
                $("#contList").append(myTmp(item));
           
            });


        }

    };

} )();