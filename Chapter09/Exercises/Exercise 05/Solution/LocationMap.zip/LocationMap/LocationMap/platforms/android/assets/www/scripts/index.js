﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.

(function () {
    "use strict";

    var accuracy, latitude, longitude, userLatLng;

    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener( 'resume', onResume.bind( this ), false );
        navigator.geolocation.getCurrentPosition(onSuccess, onError);

        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };

    function onSuccess(position) {
        userLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
        
        accuracy = position.coords.accuracy;

        initializeMap();
    };

    function onError(error) {
        alert('code: ' + error.code + '\n' + 'message: ' + error.message + '\n');
    };

    function initializeMap() {

        
        var mapOptions = {
            center: userLatLng,
            zoom: 11,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var mapObject = new google.maps.Map(document.getElementById("map"), mapOptions);

        var marker = new google.maps.Marker({
            position: userLatLng,
            map: mapObject,
            title: "This is a marker!",
            animation: google.maps.Animation.DROP
        });

        var circle = new google.maps.Circle({
            center: userLatLng,// specifying the coordinates of the user’s location
            radius: accuracy,//specifying the accuracy as the radius of the map
            map: mapObject,// map object on which the properties will be applied
            fillColor: '#0000FF',//specifying the color to be filled inside the circle
            fillOpacity: 0.5,//specifying the transparency of the circle
            strokeColor: '#0000FF',//specifying the color of the borders
            strokeOpacity: 1.0//specifying the transparency of borders
        });
        mapObject.fitBounds(circle.getBounds());

        //writeAddressName();


    };

    //function writeAddressName() {
    //    var geocoder = new google.maps.Geocoder(); /*initializing the Geocoder object */
    //    geocoder.geocode({
    //        "location": userLatLng //Setting the location property
    //    },
    //   function (results, status) /*callback function to display the success and error results of the GPS service*/ {
    //       if (status == google.maps.GeocoderStatus.OK)
    //           document.getElementById("address").innerHTML = results[0].formatted_address;//Displaying the closest formatted address
    //       else
    //           document.getElementById("error").innerHTML += "Unable to retrieve your address" + "<br />"; /*Displaying the error message if the location is unavailable*/
    //   });
    //};




})();
function locate() {
    var geocoder = new google.maps.Geocoder();
    var txtAddress = document.getElementById('txtAddress').value;
    geocoder.geocode({ 'address': txtAddress }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            var userLatLng = results[0].geometry.location;
            var myOptions = {
                zoom: 8,
                center: userLatLng
            };

            var mapObject = new google.maps.Map(document.getElementById("map"), myOptions);
            // Place the marker
            new google.maps.Marker({
                map: mapObject,
                position: userLatLng
            });
        }
    });
}