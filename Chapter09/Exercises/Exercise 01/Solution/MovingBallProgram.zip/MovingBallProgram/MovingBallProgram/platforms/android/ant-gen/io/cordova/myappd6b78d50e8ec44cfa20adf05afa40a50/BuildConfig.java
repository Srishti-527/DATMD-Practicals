/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myappd6b78d50e8ec44cfa20adf05afa40a50;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}