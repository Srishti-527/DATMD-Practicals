﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";

    var lastX, lastY;
    document.addEventListener( 'deviceready', onDeviceReady.bind( this ), false );

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener( 'pause', onPause.bind( this ), false );
        document.addEventListener('resume', onResume.bind(this), false);
        lastX = 150; lastY = 300;
        document.getElementById('img').style.left = lastX + "px";
        document.getElementById('img').style.top = lastY + "px";
        var options = {frequency:200};
        navigator.accelerometer.watchAcceleration(onSuccess,onError,options);
        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };

    function onSuccess(pass) {
        var x1, y1;
        if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/iPhone/i)) {
            var accelX = pass.x / 9.81;
            var accelY = pass.y / 9.81;
            var accelZ = pass.z / 9.81;
        }

        var distX = accelX * 100;
        var distY = (0 - accelY) * 150;
        var distZ = accelZ;
                       
        var width = window.screen.width - 50;
        var height = window.screen.height - 50;

        if (distX <= 0) {
            x1 = (lastX + distX > 0) ? (lastX + distX) : 0;
        }

        if (distX > 0) {
            x1 = (lastX + distX < width) ? (lastX + distX) : width;
        }

        if (distY <= 0) {
            y1 = (lastY + distY > 0) ? (lastY + distY) : 0;
        }

        if (distY > 0) {
            y1 = (lastY + distY < height) ? (lastY + distY) : height;
        }


        lastX = x1;
        lastY = y1;

        //if (distZ < 0) {
        //    y1 = (lastY - distY > 0) ? (lastY - distY) : 0;
        //}

        //if (distZ >= 0) {
        //    y1 = (lastY + distY < 600) ? (lastY + distY) : 630;
        //}
        document.getElementById('img').style.left = x1 + "px";
        document.getElementById('img').style.top = y1 + "px";

    };

    function onError() {


    };

})();

