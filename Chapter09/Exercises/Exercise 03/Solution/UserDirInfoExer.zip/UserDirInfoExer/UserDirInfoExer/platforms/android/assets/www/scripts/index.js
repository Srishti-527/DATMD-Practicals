﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkID=397704
// To debug code on page load in Ripple or on Android devices/emulators: launch your app, set breakpoints, 
// and then run "window.location.reload()" in the JavaScript Console.
(function () {
    "use strict";

    document.addEventListener('deviceready', onDeviceReady.bind(this), false);

    function onDeviceReady() {
        // Handle the Cordova pause and resume events
        document.addEventListener('pause', onPause.bind(this), false);
        document.addEventListener('resume', onResume.bind(this), false);
        navigator.compass.watchHeading(onSuccess, onError);

        // TODO: Cordova has been loaded. Perform any initialization that requires Cordova here.
    };

    function onPause() {
        // TODO: This application has been suspended. Save application state here.
    };

    function onResume() {
        // TODO: This application has been reactivated. Restore application state here.
    };
})();

function onSuccess(pass) {

    displayoffset = 0;
    var compensatedMagneticHeading = pass.magneticHeading + displayoffset % 360;
    var magneticCompass = document.getElementById("magneticCompass");
    magneticCompass.style.transform = "rotate(" + ((360 - compensatedMagneticHeading)) + "deg)";
    document.getElementById("magneticHeading").innerText = compensatedMagneticHeading;
    var magneticDirection = direction(compensatedMagneticHeading);
    document.getElementById("magneticDirection").innerText = magneticDirection;

}

function onError() {

}
function direction(angle) {
    var direction;
    if (angle > 337.5 || angle <= 22.5) {
        return "N";
    }
    else if (angle > 22.5 && angle <= 67.5) {
        return "NE";
    }
    else if (angle > 67.6 && angle <= 112.5) {
        return "E";
    }
    else if (angle > 112.6 && angle <= 157.5) {
        return "SE";
    }
    else if (angle > 157.6 && angle <= 202.5) {
        return "S";
    }
    else if (angle > 202.6 && angle <= 247.5) {
        return "SW";
    }
    else if (angle > 247.6 && angle <= 292.5) {
        return "W";
    }
    else if (angle > 292.6 && angle <= 337.5) {
        return "NW";
    }
}